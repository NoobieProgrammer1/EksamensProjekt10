﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EksamensProjekt10
{
    public partial class Form2 : Form
    {

        List<int> toBeSorted = new List<int>();

        public Form2()
        {
            InitializeComponent();
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
          
            string[] row = {inputField.Text};
            var listViewItem = new ListViewItem(row);
            inputList.Items.Add(listViewItem);

            toBeSorted.Add(Int32.Parse(inputField.Text));
            
        }


        private void button1_Click_1(object sender, EventArgs e)
        {
           

            int temp = 0;

            for (int i = 0; i < toBeSorted.Count; i++)
            {
                for (int j = 0; j < toBeSorted.Count - 1; j++)
                {
                    if (toBeSorted[j] > toBeSorted[j + 1])
                    {
                        temp = toBeSorted[j + 1];
                        toBeSorted[j + 1] = toBeSorted[j];
                        toBeSorted[j] = temp;
                    }
                }
            }


            for (int i =0; i <  toBeSorted.Count; i++) 
            {
                string[] row = { toBeSorted[i].ToString() };
                var listViewItem = new ListViewItem(row);
                resultList.Items.Add(listViewItem);
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            int a = toBeSorted.Count;
            for (int i = 1; i < a; i++)
            {
                int current = toBeSorted[i];
                int prevpos = i - 1;

               
                while (prevpos >= 0 && toBeSorted[prevpos] > current)
                {
                    toBeSorted[prevpos + 1] = toBeSorted[prevpos];
                    prevpos = prevpos - 1;
                }

                toBeSorted[prevpos + 1] = current;
            }

            for (int i = 0; i < a; i++)
            {
                string[] row = { toBeSorted[i].ToString() };
                var listViewItem = new ListViewItem(row);
                resultList.Items.Add(listViewItem);
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            resultList.Items.Clear();
            inputList.Items.Clear();
            toBeSorted.Clear();
        }

       
    }
}
